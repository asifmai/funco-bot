module.exports = {
  botName: 'Funco',
  siteLink: 'https://www.funko.com',
  port: '3039'
}